package com.challenge.forohub.utils.security;

public record DatosJWTToken(String jwtToken) {
}
