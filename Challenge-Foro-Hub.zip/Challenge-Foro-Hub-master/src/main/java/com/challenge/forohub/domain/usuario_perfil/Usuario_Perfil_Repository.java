package com.challenge.forohub.domain.usuario_perfil;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Usuario_Perfil_Repository extends JpaRepository<Usuario_Perfil,Long> {
}
